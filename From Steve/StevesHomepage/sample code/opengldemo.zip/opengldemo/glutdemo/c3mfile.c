#include "c3mfile.h"

/* read in mesh data from file - use free to clear up */
int C3M_ReadVertexData(char * filename, float ** fvertices, size_t * vertexCount,
					   int ** ffaces, size_t * faceCount, float ** fnormals)
{
	C3MHeader myheader;
	float * vertices, * normals;
	int * faces;
	size_t dataRead;
	FILE * dataFile = fopen(filename, "rb");

	if (!dataFile)
		return -1; /* failed */

	dataRead = fread(&myheader, sizeof(myheader), 1, dataFile);
	if (dataRead != 1)
	{
		fclose(dataFile);
		return -1;
	}

	vertices = (float *) malloc(myheader.numVertices * sizeof(float) * 3);
	if (! vertices)
	{
		fclose(dataFile);
		return -1;
	}

	faces = (int *) malloc(myheader.numFaces * sizeof(int) * 3);
	if (! faces)
	{
		fclose(dataFile);
		free(vertices);
		return -1;
	}

	normals = (float *) malloc(myheader.numVertices * sizeof(float) * 3);
	if (! normals)
	{
		fclose(dataFile);
		free(vertices);
		free(faces);
		return -1;
	}

	fread(vertices, sizeof(float) * 3, myheader.numVertices, dataFile);
	fread(faces, sizeof(int) * 3, myheader.numFaces, dataFile);
	fread(normals, sizeof(float) * 3, myheader.numVertices, dataFile);
	fclose(dataFile);

	*fvertices = vertices;
	*ffaces = faces;
	*fnormals = normals;
	*vertexCount = myheader.numVertices;
	*faceCount = myheader.numFaces;

	return 0;	/* success! */
}