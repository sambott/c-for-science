#include <stdlib.h>
#include <GL/glut.h>
#include <time.h>

#include "c3mfile.h"

/* Interval (milliseconds) between frame updates */
#define TINTERVAL 10

/* some globals */
float * vertices, * normals;
float centre[3];
size_t vertexCount, faceCount;
int *faces;
float angle;

void onRender(void)
{
	unsigned int floop, clocks;
	float angle;

	glClear(GL_COLOR_BUFFER_BIT);
	glClear(GL_DEPTH_BUFFER_BIT);
	glColorMaterial ( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE ) ;

	glLoadIdentity();
	gluLookAt(0.0, -1000.0, 5.0, 
		      0.0, 0.0,    -1.0,
			  0.0, 1.0,     0.0);

	clocks =  clock() % (CLOCKS_PER_SEC * 5);
	angle = clocks * 360.0/ (CLOCKS_PER_SEC * 5.0);
	
	glTranslatef(centre[0], centre[1], centre[2]);
	glRotatef(-angle, 0.0, 0.0, 1.0);
	glTranslatef(-centre[0], -centre[1], -centre[2]);


	glBegin(GL_TRIANGLES);
		for (floop = 0; floop < faceCount; floop++)
		{
			/* v0 */
			glNormal3fv(&normals[3*faces[3*floop]]);
			glVertex3fv(&vertices[3*faces[3*floop]]);
		
			/* v1 */
			glNormal3fv(&normals[3*faces[3*floop+1]]);
			glVertex3fv(&vertices[3*faces[3*floop+1]]);
		
			/* v2 */
			glNormal3fv(&normals[3*faces[3*floop+2]]);
			glVertex3fv(&vertices[3*faces[3*floop+2]]);
		}
	glEnd();
	glFlush();
	glutSwapBuffers();
}

void onResize(int w, int h)
{
	float ratio = 1.0* w / (h?h:1);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0, 0, w, h);
	gluPerspective(45.0, ratio, 1, 10000);
	glMatrixMode(GL_MODELVIEW);
}

void onTimer(int a)
{
	glutPostRedisplay();
	glutTimerFunc(TINTERVAL, onTimer, 0);
}

void calcCentre()
{
	unsigned int vloop;
	float xmax, xmin, ymax, ymin, zmax, zmin;

	xmax = xmin = vertices[0];
	ymax = ymin = vertices[1];
	zmax = zmin = vertices[2];

	for (vloop = 0; vloop < vertexCount; vloop++)
	{
		xmin = (xmin > vertices[vloop*3])?vertices[vloop*3]:xmin;
		ymin = (ymin > vertices[vloop*3+1])?vertices[vloop*3+1]:ymin;
		zmin = (zmin > vertices[vloop*3+2])?vertices[vloop*3+2]:zmin;

		xmax = (xmax < vertices[vloop*3])?vertices[vloop*3]:xmax;
		ymax = (ymax < vertices[vloop*3+1])?vertices[vloop*3+1]:ymax;
		zmax = (zmax < vertices[vloop*3+2])?vertices[vloop*3+2]:zmax;
	}

	centre[0] = (xmin+xmax)/2.0;
	centre[1] = (ymin+ymax)/2.0;
	centre[2] = (zmin+zmax)/2.0;
}

int main(int argc, char *argv[])
{
	int result;

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE| GLUT_RGBA);
	glutInitWindowSize(480, 480);
	glutCreateWindow("Some Things Should not be in 3d...");

	result = C3M_ReadVertexData("stemassive.c3m", &vertices, &vertexCount,
				&faces, &faceCount, &normals);

	if (result != 0)
	{
		fprintf(stderr, "Error reading data!\n");
		return result;
	}

	calcCentre();
	glutDisplayFunc(onRender);
	glutReshapeFunc(onResize);
	glutTimerFunc(TINTERVAL, onTimer, 0);

	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glutMainLoop();

	free(vertices);
	free(faces);
	return 0;
}
