#ifndef _C3MFILE_H_
#define _C3MFILE_H_

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

/* read in mesh data from file - use free to clear up */
int C3M_ReadVertexData(char * filename, float ** fvertices, size_t * vertexCount,
					   int ** ffaces, size_t * faceCount, float ** fnormals);

struct _C3MHeader
{
        char magic[7];
        char type[5]; 
        int version;            // 32 bit - 1
        int flags;              // 32 bit!
        int numVertices;        // number of vertices
        int numFaces;           // number of faces
        // version 2 added
        int numTexVertices;     // number of texture vertices...
        // version 3 added
        float ambient[3];       // ambient material properties
        float diffuse[3];       // diffuse materal properties
        float specular[3];      // specular material properties
        int shines;             // shine strength (shininess in GL)
        char unused[84];       // unused bytes
};

typedef struct _C3MHeader C3MHeader;

//Type information flags...
#define C3M_CURRENT_VERSION             3       // version 2 contains tex coords
                                                // version 3 has material properties
#define C3M_CONTAINS_NORMALS            1       // contains vertex normals
#define C3M_CONTAINS_TEXCOORDS          2       // contains texture coords
#define C3M_CONTAINS_MATERIAL           4       // contains material properties
#define C3M_ACCURATE_NORMALS            8       // normals have been recalculated

/* C3M files are arranged as follows...
C3MHeader;
float           myVertices [3*numVertices];
int             myFaces[3*numFaces];
float           myNormals[3*numVertices];    -- optional C3M_CONTAINS_NORMALS

-- optional C3M_CONTAINS_TEXCOORDS
float           texVertices[2*numTexVertices];
int             texFaces[numFaces*3];


*/


#endif /* _C3MFILE_H_ */