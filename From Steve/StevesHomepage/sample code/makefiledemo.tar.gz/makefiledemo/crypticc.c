#include <stdio.h>
#include "matrixfunctions.h"

#define SZ 3

void whatdoIdo(double *A, double * B, double *C,
			   unsigned int L, unsigned int M,
			   unsigned int N)
{
	unsigned int i, k;
	double temp, *bptr, *bend, *cptr;

	for(i=0; i < L; i++)
	{
		for (k=0; k < M; k++)
		{
			temp = A[i*M+k];
			cptr = &C[i*N];
			bptr = &B[k*N];
			bend = &B[(k+1)*N];
			while (bptr < bend)
				*cptr++ += temp*(*bptr++);
		}
	}
}

int main()
{
	double ** matrixA, **matrixB, **matrixC;
	unsigned int i, j;

	matrixA = allocMatrix(SZ, SZ);
	matrixB = allocMatrix(SZ, SZ);
	matrixC = allocMatrix(SZ, SZ);

	if (!matrixA || !matrixB || !matrixC)
	{
		fprintf(stderr, "Error allocating matrices!\n");
		return -1;
	}

	for (i=0; i < SZ; i++)
	{
		for (j=0; j < SZ; j++)
		{
			matrixA[i][j] = (i+j)%2?0:1;
			matrixB[i][j] = (i+j)%2?0:2;
			matrixC[i][j] = 0.0;
		}
	}

	printMatrix(matrixA, SZ, SZ);
	printf("\n\n");
	printMatrix(matrixB, SZ, SZ);

	whatdoIdo(matrixA[0], matrixB[0], matrixC[0], SZ, SZ, SZ);

	printf("\n\n");
	printMatrix(matrixC, SZ, SZ);	

	freeMatrix(matrixA);
	freeMatrix(matrixB);
	freeMatrix(matrixC);
	return 0;
}

