#include <stdlib.h>
#include <stdio.h>

double ** allocMatrix(unsigned int rows, unsigned int cols)
{
	double ** matrix;
	unsigned int i;

	matrix = (double **)malloc(rows*sizeof(double *));
	if (!matrix) return NULL; /* failed */

	matrix[0] = (double *) malloc (rows*cols*sizeof(double));
	if (!matrix[0])
	{
		free(matrix); /* we don't need matrix any more */
		return NULL;  /* failed */
	}

	for (i = 1; i < rows; i++)
		matrix[i] = matrix[i-1] + cols;
	return matrix;
}

void randomMatrix(double ** matrix, unsigned int rows,
									unsigned int cols)
{
	unsigned int i, j;
	for (i = 0; i < rows; i++)
		for (j = 0; j < cols; j++)
			matrix[i][j] = (double)rand()/RAND_MAX;
}

void addMatrices(double ** matrixA, double ** matrixB, double ** matrixR,
				 unsigned int rows, unsigned int cols)
{
	unsigned int i, j;
	for (i = 0; i < rows; i++)
		for (j = 0; j < rows; j++)
			matrixR[i][j] = matrixA[i][j]+matrixB[i][j];
}

void freeMatrix(double ** matrix)
{
	free(matrix[0]);
	free(matrix);
}

void printMatrix(double ** matrix, unsigned int rows,
								   unsigned int cols)
{
	unsigned int i, j;

	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
			printf("%8.5lf ", matrix[i][j]);
		printf("\n");
	}
}

