#include <stdio.h>

extern double ffunc01_(double *x);

double callfortran(double x)
{
   return ffunc01_(&x);
}

int main()
{
   double x = 1.0;
   
   printf("Hello from C!\n");
   printf("fsub(%g) = %g\n", x, callfortran(x));
   return 0;
}
