#include <stdio.h>

double cfunc01_(double * x)
{
   double retval = (*x)*(*x) - 1.0;
   printf("In cfunc01(): received x = %g, returning: %g\n", *x, retval);
   return retval;
}
