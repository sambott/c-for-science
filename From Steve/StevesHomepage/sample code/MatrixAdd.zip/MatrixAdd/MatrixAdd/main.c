#include <stdio.h>

#include "util.h"

int main()
{
	unsigned int rows, cols;
	double ** matrixA, ** matrixB, **matrixC;

	printf("Enter rows cols: ");
	scanf("%u %u", &rows, &cols);
	matrixA = allocMatrix(rows, cols);
	matrixB = allocMatrix(rows, cols);
	matrixC = allocMatrix(rows, cols);
	if (!matrixA || !matrixB || !matrixC)
	{ /* a little lazy, but it does the job */
		fprintf(stderr, "Unable to allocate matrices!\n");
		return -1;
	}

	randomMatrix(matrixA, rows, cols);
	randomMatrix(matrixB, rows, cols);
	addMatrices(matrixA, matrixB, matrixC, rows, cols);

	printf("\n\nmatrix A = \n");
	printMatrix(matrixA, rows, cols);
	printf("\n\nmatrixB = \n");
	printMatrix(matrixB, rows, cols);
	printf("\n\nmatrixA + matrixB = \n");
	printMatrix(matrixC, rows, cols);

	freeMatrix(matrixC);
	freeMatrix(matrixB);
	freeMatrix(matrixA);
	return 0;
}
