/* allocate matrix, return NULL on failure */
double ** allocMatrix(unsigned int rows, unsigned int cols);

/* free allocated matrix */
void freeMatrix(double ** matrix);

/* print matrix to stdout */
void printMatrix(double ** matrix, unsigned int rows, unsigned int cols);

/* populate pre-allocated with random numbers */
void randomMatrix(double ** matrix, unsigned int rows, unsigned int cols);

/* add two matrices together matrixR = matrixA + matrixB */
void addMatrices(double ** matrixA, double ** matrixB, double ** matrixR,
unsigned int rows, unsigned int cols);