#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

double ** allocMatrix(unsigned int rows, unsigned int cols)
{
	double ** matrix;
	unsigned int i;
	
	assert((rows > 0) && (cols > 0));

	matrix = (double **)malloc(rows*sizeof(double *));
	if (!matrix) return NULL; /* failed */

	matrix[0] = (double *) malloc (rows*cols*sizeof(double));
	if (!matrix[0])
	{
		free(matrix); /* we don't need matrix any more */
		return NULL;  /* failed */
	}

	for (i = 1; i < rows; i++)
		matrix[i] = matrix[i-1] + cols;
	return matrix;
}

void randomMatrix(double ** matrix, unsigned int rows,
									unsigned int cols)
{
	unsigned int i, j;
	assert(matrix && (rows > 0) && (cols > 0));
	for (i = 0; i < rows; i++)
		for (j = 0; j < cols; j++)
			matrix[i][j] = (double)rand()/RAND_MAX;
}

void addMatrices(double ** matrixA, double ** matrixB, double ** matrixR,
				 unsigned int rows, unsigned int cols)
{
	unsigned int i, j;
	
	assert(matrixA && matrixB && matrixR && (rows > 0) && (cols > 0));
	
	for (i = 0; i < rows; i++)
		for (j = 0; j < rows; j++)
			matrixR[i][j] = matrixA[i][j]+matrixB[i][j];
}

void freeMatrix(double ** matrix)
{
	assert(matrix);
	
	free(matrix[0]);
	free(matrix);
}

void printMatrix(double ** matrix, unsigned int rows,
								   unsigned int cols)
{
	unsigned int i, j;
	
	assert(matrix && (rows > 0) && (cols > 0));

	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
			printf("%8.5f ", matrix[i][j]);
		printf("\n");
	}
}

