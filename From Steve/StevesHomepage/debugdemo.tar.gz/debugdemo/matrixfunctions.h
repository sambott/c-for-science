#ifndef _MATRIXFUNCTIONS_H_
#define _MATRIXFUNCTIONS_H_

double ** allocMatrix(unsigned int rows, unsigned int cols);
void randomMatrix(double ** matrix, unsigned int rows,
									unsigned int cols);

void addMatrices(double ** matrixA, double ** matrixB, double ** matrixR,
				 unsigned int rows, unsigned int cols);

void freeMatrix(double ** matrix);
void printMatrix(double ** matrix, unsigned int rows,
								   unsigned int cols);


#endif /* _MATRIXFUNCTIONS_H_ */
