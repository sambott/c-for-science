void printPrimes(char * Prime_List, int max_num);
void findPrimes(char * Prime_List, int max_num);
int countPrimes(char * Prime_List, int max_num);
